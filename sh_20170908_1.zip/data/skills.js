﻿$( function() {

  var cache = $.cache._();

  var skills = [
  ];
  cache.set( "skills", skills, true );

} );
