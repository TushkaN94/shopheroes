﻿$( function() {
  $( '#tabs' ).tabs();
} );
